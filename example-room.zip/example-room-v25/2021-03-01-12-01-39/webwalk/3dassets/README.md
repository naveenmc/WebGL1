Avatar is exported from Blender with head facing the positive
direction of the Y axis and with the following exporting options:
Forward: Y Forward
Up: Z Up

Head rotation center is at 0.0, and torso is positioned above the head
at the actual height at which avatar should fly (head is moved to be
above the head by JavaScript code).
